#pragma once
#include "esphome.h"
static const char *TAG = "mijiaBleMessage";

class mijiaBleMessage : public Component, public CustomMQTTDevice {
 public:
  void setup() override {
    Serial.begin(115200);
  }
  void loop() override 
  {
    while(Serial.available()){
      this->readline_(Serial.read());
    }
  }
 protected:
  // 存储每行 UART 消息
  std::vector<char> rx_message_;

  // 获取 json 字符
  char * getJson_(char * inChar){
    char *json = strstr(inChar,"{");
    if (!json) {return NULL;}
    char *pch=strrchr(json,'}');
    if (pch)
    {
      json[pch-json+1] = 0;
      return json;
    } else {
      return NULL;
    }
  }

  // 获取每行消息
  void readline_(int c)
  {
    if (c > 0){
      switch (c) {
        case '\n':
          break;
        case '\r':
        {
          // 字符串终止符
          rx_message_.push_back(0x00);
          // 解析 rx 的消息
          this->handle_();
          // 清除缓冲区
          this->rx_message_.clear();
          break;
        }
        default:
          this->rx_message_.push_back(c);
      }
    }
  }

  // 消息处理
  void handle_(){
    char *data = &rx_message_[0];
    // 查找 ots 消息
    char *otsMessage = strstr(data,"ots:");
    if(!otsMessage){
      return;
    }
    //ESP_LOGD(TAG, "[otsMessage:] %s",  data);

    // 判断是否蓝牙事件
    if(!strstr(data,"_async.ble_event")){
      return;
    }
    char *json = getJson_(data);
    if(!json){
      ESP_LOGD(TAG, "Json not found. [otsMessage]: %s", data);
      return;
    }
    ESP_LOGD(TAG, "[bluetooth event] %s", data);
    // 蓝牙事件 json 例子:
    // {"id":1518998071,"method":"_async.ble_event","params":{"dev":{"did":"1011078646","mac":"AA:BB:CC:DD:EE:FF","pdid":794},"evt":[{"eid":7,"edata":"0036f6e45e"}],"frmCnt":97,"gwts":2362}}
    StaticJsonBuffer<500> jsonBuffer;
    JsonObject& jsonData = jsonBuffer.parseObject(json);

    // json 解析失败
    if(!jsonData.success()){
      ESP_LOGD(TAG, "Json parse failed. string:%s", json);
      return;
    }

    // 获取 did
    JsonObject& dev = jsonData["params"]["dev"];
    const char *did = dev.get<const char*>("did");
    if(!did){
      ESP_LOGD(TAG, "did is not found.");
      return;
    }
    
    // 遍历数组获取edata与eid
    if(!jsonData["params"]["evt"].is<JsonArray>()){
      ESP_LOGD(TAG, "evt is not an array.");
      return;
    }
    JsonArray &arr = jsonData["params"]["evt"];
    for (auto value : arr){
      const char *eid = value["eid"].as<char*>();
      char edata[20]={0};
      strcpy(edata,value["edata"].as<char*>());
      if (strlen(edata) == 0)
      {
        ESP_LOGD(TAG, "edata is not found.");
        break;
      }
      this->reverse_(edata);
      this->mqttPublish_(did,eid,edata);
      // char payload[500];
      // value.printTo ( payload, 500);
      // this->mqttPublish_(did, payload);
    }
  }

  // 两字节高低转换
  void reverse_(char *inChar){
    size_t l = strlen(inChar);
    for (int i = 0,j=l-2; i<j; i++,j=j-3)
    {
      char a = inChar[i];
      inChar[i] = inChar[j];
      inChar[j] = a;
      i++;
      j++;
      char b = inChar[i];
      inChar[i] = inChar[j];
      inChar[j] = b;
    }
  }

  // 发送 mqtt 消息
  void mqttPublish_(const char *deviceID, const char *payload){
    char topic[80];
    sprintf(topic,"/mijiaBleListener/%s/evt",deviceID);
    publish(std::string(topic), std::string(payload));
  }

  // 发送 mqtt 消息
  void mqttPublish_(const char *deviceID, const char *eid, const char *edata){
    char topic[80];
    sprintf(topic,"/mijiaBleListener/%s/%s",deviceID,eid);
    publish(std::string(topic), std::string(edata));
  }
};